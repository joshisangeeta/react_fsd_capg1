import { createStore, applyMiddleware } from "redux";
import employees from '../reducers/empreducer';
import thunk from 'redux-thunk';
export default () => {
  
    return createStore(employees, applyMiddleware(thunk));
};