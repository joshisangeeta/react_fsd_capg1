import React, { useState } from "react";
import { Link, useHistory } from 'react-router-dom';
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import green from "@material-ui/core/colors/green";
import { Router } from "react-router-dom";

// react.school/material-ui

const useStyles = makeStyles((theme) => ({
  menuButton: {
    marginRight: theme.spacing(2)
  },
  title: {
    flexGrow: 1
  },
  customColor: {
    // or hex code, this is normal CSS background-color
    backgroundColor: green[500]
  },
  customHeight: {
    minHeight: 200
  },
  offset: theme.mixins.toolbar
}));

export default function ButtonAppBar() {
  const classes = useStyles();
  const history = useHistory();
  const [example, setExample] = useState("primary");
  const isCustomColor = example === "customColor";
  const isCustomHeight = example === "customHeight";
  return (
    <React.Fragment>
      <AppBar
        color={isCustomColor || isCustomHeight ? "primary" : example}
        className={`${isCustomColor && classes.customColor} ${
          isCustomHeight && classes.customHeight
        }`}
      >
        <Toolbar>
          <IconButton
            edge="start"
            className={classes.menuButton}
            color="inherit"
            aria-label="menu"
            size="small"
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" className={classes.title}>
            Employee Management System
          </Typography>
          
          <IconButton color="inherit" size="small" className={classes.menuButton}
            color="inherit" onClick={() => {  history.push("/addemp")}}>
            <Typography variant="h16" className={classes.menuButton}>
              Add-Employee
           </Typography> 
          </IconButton>  
          <IconButton color="inherit" size="small" onClick={() => {  history.push("/employees")}}  >
            <Typography variant="h16" className={classes.push}>                   
              Show-All-Employees
            </Typography> 
            </IconButton>
          {/*  <Link to="/employees">Show employees</Link> */}
        </Toolbar>
      </AppBar>
      <Toolbar />
     
     
    </React.Fragment>
  );
}
