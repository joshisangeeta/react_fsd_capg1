import React, { Component } from 'react'
import EmployeeService from '../services/EmployeeService';
import Button from "@material-ui/core/Button";
class CreateEmployeeComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            id: this.props.match.params.id,
            dept:'',
            firstName: '',
            lastName: '',
            emailId: ''
        }
        this.onSubmit=this.onSubmit.bind(this);
        this.changeFirstNameHandler = this.changeFirstNameHandler.bind(this);
        this.changeLastNameHandler = this.changeLastNameHandler.bind(this);
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
        this.saveOrUpdateEmployee = this.saveOrUpdateEmployee.bind(this);
        this.changeDeptHandler = this.changeDeptHandler.bind(this)
    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.id === '_add'){
           return
        }else{
            EmployeeService.getEmployeeById(this.state.id).then( (res) =>{
                let employee = res.data;
                this.setState({firstName: employee.firstName,
                    lastName: employee.lastName,
                    emailId : employee.emailId,
                    dept:employee.dept
                });
            });
        }        
    }
    saveOrUpdateEmployee = (e) => {
        e.preventDefault();
       // alert("hi");
        let employee = {firstName: this.state.firstName, lastName: this.state.lastName, emailId: this.state.emailId,dept:this.state.dept};
        console.log('employee => ' + JSON.stringify(employee));

        EmployeeService.updateEmployee(employee, this.state.id).then( res => {
          //  alert("from server");
        this.props.history.push('/');});
        // step 5
     //   if(this.state.id === '_add'){
     //       EmployeeService.createEmployee(employee).then(res =>{
     //           this.props.history.push('/employees');
     //       });
     //   }else{
     //       EmployeeService.updateEmployee(employee, this.state.id).then( res => {
      //          this.props.history.push('/employees');
     //       });
     //   }
    }
    
    changeFirstNameHandler= (event) => {
       // alert("fName"+event.target.value)
        this.setState({firstName: event.target.value});
    }

    changeLastNameHandler= (event) => {
      //  alert("lName"+event.target.value)
        this.setState({lastName: event.target.value});
    }
    changeDeptHandler=(event)=>{
        this.setState({dept:event.target.value});
    }

    changeEmailHandler= (event) => {
      //  alert("email"+event.target.value)
        this.setState({emailId: event.target.value});
    }

    cancel(){
        this.props.history.push('/employees');
    }
    onSubmit(e) {
        e.preventDefault();
        let employee = {firstName: this.state.firstName, lastName: this.state.lastName, emailId: this.state.emailId};
        console.log('employee => ' + JSON.stringify(employee));

        if (!this.state.firstName || !this.state.lastName ) {
            this.setState((state) => ({ ...state, error: 'Please set firstname & lastName!' }));
        } else {
            this.setState((state) => ({  ...state,error: '' }));
            this.props.onSubmitEmployee(
                
                {
                    firstName: this.state.firstName,
                    lastName: this.state.lastName,
                    emailId : this.state.emailId
                    
                },
                
            );
           // 
        }
        
    }

    getTitle(){
        if(this.state.id === '_add'){
            return <h3 className="text-center">Add Employee</h3>
        }else{
            return <h3 className="text-center">Update Employee</h3>
        }
    }
    render() {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
               
                   <div className = "container">
                        <div className = "row">
                            <div  >
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                <form onSubmit={this.onSubmit}   >
                                    <div >
                                        <div className="form-group">
                                            <label> Choose Department</label>
                                        </div>
                                        <div>
                                            <select value={this.state.dept} required onChange={this.changeDeptHandler}>Select Department
                                               <option>HR</option>
                                                <option>Development</option>
                                                <option>Tech-Support</option>
                                                <option>Finanace</option>
                                            </select>       
                                        </div>
                                        <div className = "form-group">
                                            <label> First Name: </label>
                                            <input placeholder="First Name" required className="form-control" 
                                                value={this.state.firstName} onChange={this.changeFirstNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Last Name: </label>
                                            <input placeholder="Last Name" required className="form-control" 
                                                value={this.state.lastName} onChange={this.changeLastNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Email Addr: </label>
                                            <input placeholder="Email Address" required className="form-control" 
                                            value={this.state.emailId} onChange={this.changeEmailHandler}/>
                                        </div>
                                        {this.state.error && <b className="m-1 text-danger">{this.state.error}</b>}
                                        {/*<button className="btn btn-success" onClick={this.onSubmit} style={{marginLeft: "10px"}}>Add</button>*/}
                                        <br></br>
                                       
                                        <div className="form-group">
                                            <Button color="primary" size="small" variant="contained" className="btn btn-success" onClick={this.saveOrUpdateEmployee}>UpdateNSave</Button> 
                                            <Button color="primary" size="small" variant="contained" className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</Button>
                                         </div>
                                    </div>  
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default CreateEmployeeComponent

