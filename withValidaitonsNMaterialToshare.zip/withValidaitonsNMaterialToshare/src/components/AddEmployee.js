import React from 'react';
import AddEmployeeComponent from './AddEmployeeComponent';
import { connect } from 'react-redux';
import { addEmployee } from '../actions/actions';

const AddEmployee = (props) => (
    <div  >
       
        <AddEmployeeComponent employee={props.employee}
            handleCancel={()=>{props.history.push('/');}}
            onSubmitEmployee={(employee) => {
               // console.log("hi "+employee.firstName+employee.lastName+employee.emailId+employee.dept)
                props.dispatch(addEmployee(employee));
                props.history.push('/');
            }}
        />
    </div>
);

const mapStateToProps = (state,props) => {
    return {
                    employee:state
    };
};

export default connect(mapStateToProps)(AddEmployee);

