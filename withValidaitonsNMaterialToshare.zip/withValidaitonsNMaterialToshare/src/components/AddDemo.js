import React, { Component } from 'react'
class AddEmp extends Component{
    
}