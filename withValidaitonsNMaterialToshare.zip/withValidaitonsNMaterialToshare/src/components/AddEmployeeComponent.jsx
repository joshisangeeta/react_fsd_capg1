import React, { Component } from 'react'
import EmployeeService from '../services/EmployeeService';
import Button from "@material-ui/core/Button";
class AddEmployeeComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            dept:'HR',
            firstName: '',
            lastName: '',
            emailId: '',
            errors:{}
        }
        this.onSubmit=this.onSubmit.bind(this);
        this.changeFirstNameHandler = this.changeFirstNameHandler.bind(this);
        this.changeLastNameHandler = this.changeLastNameHandler.bind(this);
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
        this.changeDeptHandler = this.changeDeptHandler.bind(this);
     
    }

    // step 3
    componentDidMount(){

        // step 4
       
    }
    validate(){
        let isValid=true;
        let errors = {};
        if(!this.state.firstName){
        errors["firstName"]="First Name should not be blanck";
          isValid=false;
        }
        if (!this.state.firstName){
            errors["firstName"] = "First Name should not be blanck";
            isValid = false;
        }
        if (!this.state.lastName){
            errors["lastName"] = "Last Name should not be blanck";  
            isValid = false;
        }  
        if (!this.state.emailId){
            errors["emailId"] = "Email id should not be blanck";
            isValid = false;
        }

        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
        if (this.state.emailId && !pattern.test(this.state.emailId)) {
            isValid = false;
            errors["emailId"] = "Please enter valid email address.";
        }

        
        this.setState({
            errors:errors
        })    
 
       return isValid;
    }
    
    
    changeFirstNameHandler= (event) => {
       // alert("fName"+event.target.value)
        this.setState({firstName: event.target.value});
    }
    changeDeptHandler = (event)=>{
        //alert("handler")
        this.setState({dept:event.target.value})
    }

    changeLastNameHandler= (event) => {
      //  alert("lName"+event.target.value)
        this.setState({lastName: event.target.value});
    }

    changeEmailHandler= (event) => {
      //  alert("email"+event.target.value)
        this.setState({emailId: event.target.value});
    }

    cancel(){
        this.props.handleCancel();
       // this.props.history.push('/employees');
    }
    onSubmit(e) {
        e.preventDefault();
        let employee = {dept: this.state.dept,firstName: this.state.firstName, lastName: this.state.lastName, emailId: this.state.emailId};
        console.log('employee => ' + JSON.stringify(employee));

        //if (!this.state.firstName || !this.state.lastName  ) {
         //   if(!this.validate()){
       //     this.setState((state) => ({ ...state, error: 'Please set firstname! and or lastName!' }));
       // } 
       
       // else {
                if (this.validate())  {
                    alert('in validate')
            this.setState((state) => ({  ...state,errors: {} }));
            this.props.onSubmitEmployee(
                
                {
                    firstName: this.state.firstName,
                    lastName: this.state.lastName,
                    emailId : this.state.emailId,
                    dept:this.state.dept
                    
                },
                
            );
           // 
        }
        
    }

    getTitle(){
        
            return <h3 className="text-center">Add Employee</h3>
        
    }
    render() {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
                
                   <div className = "container" >
                   
                   
                        <h3>Set Employee information:</h3>
                        
                        <div className = "row">
                            <div >
                                {
                                    this.getTitle()
                                }
                                
                                    
                                <form onSubmit={this.onSubmit} class="justify-content-center"   >
                                <div className="card-body">
                                    <div className="form-group">
                                           <label> Choose Department</label>
                                        </div>
                                        <div>
                                        <select value={this.state.dept} required onChange={this.changeDeptHandler}>Select Department
                                               <option>HR</option>
                                               <option>Development</option>
                                               <option>Tech-Support</option>
                                               <option>Finanace</option>
                                           </select>                                           
                                        </div>
                                        <div className = "form-group">
                                            <label> First Name: </label>
                                            <input placeholder="First Name" required className="form-control" 
                                                value={this.state.firstName} onChange={this.changeFirstNameHandler}/>
                                          <div   style={{ color: 'red' }}> {this.state.errors.firstName && <i className="text-danger">{this.state.errors.firstName}</i>}
                                        </div>
                                        </div>
                                        <div className = "form-group">
                                            <label> Last Name: </label>
                                            <input placeholder="Last Name" required className="form-control" 
                                                value={this.state.lastName} onChange={this.changeLastNameHandler}/>
                                        <div style={{ color: 'red' }}>
                                        {this.state.errors.lastName && <i className="m-1 text-danger">{this.state.errors.lastName}</i>}
                                         </div>
                                        </div>
                                        <div className = "form-group">
                                            <label> Email Addr: </label>
                                            <input type="email" placeholder="Email Address" required className="form-control" 
                                                value={this.state.emailId} onChange={this.changeEmailHandler}/>
                                        <div style={{ color: 'red'}}>                                       
                                        {this.state.errors.emailId && <i className="m-1 text-danger">{this.state.errors.emailId}</i>}
                                        </div>
                                        </div>
                                   
                                  
                                       <br></br>
                                      <div className="form-group">
                                        <Button color="primary" size="small" variant="contained" className="btn btn-success" onClick={this.onSubmit} style={{marginLeft: "5px"}}>Add</Button>
                                      {/**  <button className="btn btn-success" onClick={this.saveOrUpdateEmployee}>UpdateNSave</button> */}
                                        <Button color="primary" size="small" variant="contained" className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "5px"}}>Cancel</Button>
                                    </div> 
                                       </div>     
                                    </form>
                             
                            </div>
                            </div>
                        </div>

                   </div>
            
        )
    }
}

export default AddEmployeeComponent

