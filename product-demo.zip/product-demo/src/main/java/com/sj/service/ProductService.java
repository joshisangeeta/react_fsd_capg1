package com.sj.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sj.entity.Product;
import com.sj.repository.IProductRepo;

@Service
public class ProductService implements IProductService {
	
    @Autowired 
	IProductRepo productRepo;
	
	@Override
	public String getWelcomeMsg() {
		return "Hello world ..welcome to app"+"first product";
	}

	@Override
	public Product getProductById(int id) {
		 
		
		
		// TODO Auto-generated method stub
		return productRepo.findOne(id);
	}

	@Override
	public Product createProduct(Product product) {
		// TODO Auto-generated method stub
		
	       return productRepo.save(product);
	
	
	}

	@Override
	public List<Product> getByName(String name) {
		// TODO Auto-generated method stub
		return  productRepo.findByName(name);
	}
	
	
	

}
