package com.sj.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sj.entity.Product;

@Service
public interface IProductService {
	
	
	public String getWelcomeMsg();

	public Product getProductById(int id);

	public Product createProduct(Product product);

	public List<Product> getByName(String name);

}
