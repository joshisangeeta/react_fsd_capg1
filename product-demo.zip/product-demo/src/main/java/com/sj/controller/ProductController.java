/**
 * 
 */
package com.sj.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sj.entity.Product;
import com.sj.service.IProductService;

/**
 * @author sangeeta

 *
 */
@RestController
@RequestMapping("/api")
public class ProductController {
	
	@Autowired
	IProductService productService;
	
	@GetMapping("/hi")
	public String sayHi() {
		
     	return	productService.getWelcomeMsg();
	}
	
	@GetMapping("products/{id}")
	public Product getProductById(@PathVariable int id) {
		
		return productService.getProductById(id);
		
	}
	
	
	@GetMapping("products/byname/{name}")
	public List<Product> getByProductName(@PathVariable String name){
		return productService.getByName(name);
	}
	
	@PostMapping("products")
	public Product createProduct (@RequestBody Product product) {
		
		return productService.createProduct(product);
		
	}
	
	//public Product getProductById(int id) {
		
	//}
	
	

}
