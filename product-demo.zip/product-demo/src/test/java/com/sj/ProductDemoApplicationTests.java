package com.sj;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
